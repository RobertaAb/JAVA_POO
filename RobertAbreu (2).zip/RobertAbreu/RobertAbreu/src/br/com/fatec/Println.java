package br.com.fatec;

public class Println {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Print, Al� mundo!!");
	}

}
