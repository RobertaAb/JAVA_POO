package br.com.fatec;

public class orNot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 3;
		int y = 5;
		int z = 7;

		System.out.println("x � maior do que y? " + (x > y));
		System.out.println("x � maior do que y ou maior do que z? " + (x > y || x > z ));

		System.out.println("x N�O � maior do que y ou N�O � maior do que z? " + (!(x > y) || !(x > z )));

		System.out.println("x � diferente de z? " + (x != z));

		System.out.println("x � maior do que y E maior do que z? " + (x > y && x > z ));
	}

}
