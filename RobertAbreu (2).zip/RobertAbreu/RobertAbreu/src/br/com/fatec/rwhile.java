package br.com.fatec;

public class rwhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int quantidadeAsteristico =8;
	System.out.println("********");
	while (quantidadeAsteristico >0) {
		System.out.println("*       *");
		quantidadeAsteristico--;
		
	}
	
	System.out.println("*********");
	}

}
