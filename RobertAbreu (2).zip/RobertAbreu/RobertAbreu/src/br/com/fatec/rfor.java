package br.com.fatec;

public class rfor{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("*********");
	 for (int quantidadeAsteristico =8; quantidadeAsteristico > 0; quantidadeAsteristico--) {
		System.out.println("*       *");
					}
	
	System.out.println("*********");
	}

}