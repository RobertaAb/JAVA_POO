//2. Escreva um aplicativo que solicita ao usu�rio inserir dois n�meros
//inteiros e imprima a soma, a m�dia e imprima os n�meros em ordem
//crescente.

package br.com.fatec2;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
