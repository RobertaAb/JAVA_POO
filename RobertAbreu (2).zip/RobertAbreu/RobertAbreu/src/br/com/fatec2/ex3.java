// 3 - Escreva um aplicativo que solicita ao usu�rio inserir cinco n�meros inteiros e imprima
//o maior, o menor n�mero do grupo.

package br.com.fatec2;

public class ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
