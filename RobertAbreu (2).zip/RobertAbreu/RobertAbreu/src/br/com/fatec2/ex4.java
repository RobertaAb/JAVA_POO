//4. Escreva um aplicativo que l� dois inteiros, determina se o 
// primeiro � um m�ltiplo do segundo.

package br.com.fatec2;

public class ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
