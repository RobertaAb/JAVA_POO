
//1. Escreva um aplicativo que solicita ao usu�rio inserir dois
//n�meros inteiros e imprima a soma, subtra��o, divis�o e produto
//desses dois n�meros.

package br.com.fatec2;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
