//7. Desenvolva um aplicativo que determine o sal�rio de um empregado que
// recebe por hora trabalhada. A empresa paga �hora normal� para as primeiras
// 40 horas trabalhadas e 50% a mais para todas as horas trabalhadas al�m
//das 40 horas. O aplicativo deve receber a quantidade de horas trabalhadas 
//e o valor da hora normal e calcular o sal�rio bruto do empregado.

package br.com.fatec2;

public class ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
