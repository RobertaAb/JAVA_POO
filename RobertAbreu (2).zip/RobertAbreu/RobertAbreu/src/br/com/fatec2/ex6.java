//6. Considere uma grande empresa que paga seu pessoal de vendas com base
// em comiss�es. O pessoal de vendas recebe R$ 200 por semana mais 9% de 
//suas vendas brutas durante a semana. Desenvolva um aplicativo que receba 
// a entrada de itens vendidos por um vendedor durante a �ltima semana e 
//calcule e exibe os rendimentos do vendedor.

package br.com.fatec2;

public class ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
