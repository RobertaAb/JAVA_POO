package br.com.fatec;

public class Print {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Print, Al� mundo!!");
	}

}
